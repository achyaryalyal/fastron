#Permissions

Modify file permissions through the file manager of Codiad

##Installation

- Download the zip file and unzip it to your plugin folder.

##Screenshot

![Screenshot](http://andrano.de/Plugins/img/permissions.jpg)