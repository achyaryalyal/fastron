<?php
$lang = array();
?>
